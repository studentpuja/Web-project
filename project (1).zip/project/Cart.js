function displayProduct(){
    let cart = JSON.parse(localStorage.getItem("cart")) || []
    console.log(cart)
    let cartContent = document.getElementById("cartConent")
    let totalPrice = document.getElementById("totalPrice")
    let total =0;
    if(cart.length == 0){
        cartContent.innerHTML = `
        <h2 style="text-align:center;">Cart is empty</h2><br>
        `
        totalPrice.innerHTML = ""
    }
    cart.map((product,index)=>{
        console.log(product)
        total += product.price

        let productDiv = document.createElement("main")
        productDiv.innerHTML = `
           <div>
             <img src="${product.images[0]}" height="200" />
             <h3>${product.title}</h3>
             <p>Category : ${product.category}</p>
             <p> availabilityStatus: ${product.availabilityStatus}</p>
             <p>warrantyInformation : ${product.warrantyInformation}</p>
             <p> returnPolicy : ${product.returnPolicy}</p>
             <p>stock : ${product.stock}</p>
             <p>shippingInformation : ${product.shippingInformation}</p>
             <p>price : $${product.price}</p>
            </div>
             <button onclick="removePro(${index})">remove</button>
        `
        cartContent.append(productDiv)
    })
    totalPrice.innerHTML = `<h3>total Price :$${total.toFixed(2)}</h3>`
}

displayProduct()

function removePro(ind){
    let cart = JSON.parse(localStorage.getItem("cart")) || []
    cart.splice(ind,1)
    localStorage.setItem("cart" , JSON.stringify(cart));
    displayProduct()
    location.reload()
}