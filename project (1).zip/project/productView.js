
let productDetails = document.getElementById("productDetails");

let products = JSON.parse(localStorage.getItem("products"));

let selectedProductId = localStorage.getItem("productId");

if (products && selectedProductId) {
    let selectedProduct = products.find(product => product.id == selectedProductId);
    if (selectedProduct) {
        console.log(selectedProduct)
        productDetails.innerHTML = `
      <div class="prod-container">
      <div class="card">
                <img src="${selectedProduct.images[0]}" height="200" alt="${selectedProduct}"/>
      <div class="col-md-6 prod-des">
        <h1>${selectedProduct.title}</h1>
                 <p> <strong>Brand: </strong> ${selectedProduct.brand}</p >
                 <p><strong>Category:</strong> ${selectedProduct.category}</р>
                 <p><strong>Description:</strong> ${selectedProduct.description}</p>
                 <p><strong>Price:</strong> $${selectedProduct.price.toFixed(2)}</p>
                <div class="btn-container">
                <button id="addToCartBtn" class="cart-btn">Add to Cart</button>
                <button class="back-home"> <a href="homePage.html">Back to Home</a></button>
        </div>
        </div>
        </div>
       <div class="row reviews">
            <h2>Customer Reviews</h2>
            ${selectedProduct.reviews.map(review =>
            `
                <div>
                <hr>
                  <div>${'❤️'.repeat(review.rating)} ${'🖤'.repeat(5 - review.rating)}</div>
                  <p>${review.comment}</p>
                  <small>By ${review.reviewerName} on ${new Date(review.date).toLocaleDateString()}</small>
                  </div>
                `
        ).join("")}
       </div>
    </div>  `
        document.getElementById("addToCartBtn").addEventListener("click", () => {
            addToCart(selectedProduct)
        })
    }
} else
    productDetails.innerHTML = "<p>No product selected.</p>";

function addToCart(product) {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    let res = cart.find(val => val.id == product.id)
    if (res) {
        alert("Product already in cart")
    } else {
        cart.push(product);
        localStorage.setItem("cart", JSON.stringify(cart));
        alert("Product added to cart")
    }
}
