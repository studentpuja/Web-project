let products = []
let container = document.getElementById("cnt");
let productDetails = ""
function fetchData(){
    window.fetch("https://dummyjson.com/products").then(val=> val.json()).then(res =>{
        products = res.products 
        displayData(products)
        localStorage.setItem("products" , JSON.stringify(products))
    })
}
function displayData(pro){
    productDetails = ""
    console.log(pro);
     pro.map(val=>{
        console.log(val);
        productDetails += `
            <div class="card">
             <img src="${val.images[0]}" height="140" width="140">
            <h2>${val.title}</h2>
            <p><b>Price:</b> $${val.price}</p>
            <article>
            <main class="rating">
            ${val.rating}
            <i class="fa-solid fa-star"></i>
            </main>
            <button class="viewmore" onclick="viewmore(${val.id})">viewmore</button>
            </article>
            </div>
        `
     })

   container.innerHTML = productDetails  
}

function viewmore(id){
    localStorage.setItem("productId" , id)
   window.location.assign("./productView.html")
}

function searchProduct(val){
    let searchTerm = val.target.value.toLowerCase()
  let filteredProducts =  products.filter(val=>
       val.title.toLowerCase().includes(searchTerm) ||
      val.category.toLowerCase().includes(searchTerm)
  )
  displayData(filteredProducts)
}

document.getElementById("input").addEventListener("input" , searchProduct)

fetchData()